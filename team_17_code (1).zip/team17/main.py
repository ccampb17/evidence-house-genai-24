from flask import Flask, render_template, request, jsonify
import os
import json

app = Flask(__name__, template_folder='page')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/accordion')
def accordion():
    return render_template('accordion.html')


@app.route('/index2')
def index2():
    return render_template('index2.html')


@app.route('/results')
def results():
    return render_template('results.html')

@app.route('/upload')
def upload():
    return render_template('upload.html')

@app.route('/process_ex_notes')
def process_ex_notes():
    return render_template('process-ex-notes.html')

@app.route("/upload", methods=["GET", "POST"])
def upload_file():
    if request.method == "POST":
        # Check if the file is present
        if 'file' not in request.files:
            return "No file selected!"

        file = request.files['file']
        # Check if filename is empty
        if file.filename == '':
            return "No file selected!"
        
        # Save the file (replace with your desired logic)
        filename = file.filename
        file.save(os.path.join("uploads", filename))
        return f"File {filename} uploaded successfully!"
    
    return render_template("page/upload.html") 

import subprocess

@app.route("/process", methods=["POST"])
def process_data():
    # Run the Python script (replace with actual script path)
    subprocess.run(["python", "processing/langchain-ex-notes.py"])
    return "Script executed!"

# @app.route("/get_output")
# def get_output():
#     try:
#         with open("outputs/ex-notes-output.txt", "r") as f:
#             output = f.read()
#         return output
#     except FileNotFoundError:
#         return "Output file not found."

@app.route("/get_output")
def get_output():
    try:
        with open("llm_output/ex-notes-output.txt", "r") as f:
            output_list = json.load(f)  # Load data as a list
        return jsonify(output_list)   # Return data as JSON
    except FileNotFoundError:
        return "Output file not found."

# ... (existing imports and routes) ...

@app.route("/convert_pdf", methods=["POST"])
def convert_pdf():
    # Add your PDF conversion logic here
    # This is a placeholder - you will need to implement the actual conversion process
    subprocess.run(["python", "processing/pdf-txt.py"])  
    return "PDF Conversion Started (Placeholder)" 


if __name__ == '__main__':
    app.run(debug=True, port=8081)