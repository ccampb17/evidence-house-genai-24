from pdf2image import convert_from_path
from pdf2image.exceptions import (
    PDFInfoNotInstalledError,
    PDFPageCountError,
    PDFSyntaxError
)
from pdfminer.high_level import extract_text
import base64
from io import BytesIO
import os
import concurrent
from tqdm import tqdm
from openai import OpenAI
import re
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import json
import numpy as np
from rich import print
from ast import literal_eval

class pdf_reader:
  def __init__(self, input_path, output_name):
    self.input_path = input_path
    self.output_name = output_name

  def write_pdf(self):
    self.images = convert_from_path(self.input_path)
    self.text = extract_text(self.input_path)
    output_path = f"./outputs/{self.output_name}.txt"
    pattern = r'^\s*(?:\w+\s+){0,10}\w+\s*$'
    # Use re.findall() to find lines with fewer than 10 words
    formatted_text = re.sub(pattern, '', self.text, flags=re.MULTILINE)
    pattern = r'\b(?:\w+\W+){10,}\w+\b[.!?]'
    # Use re.findall() to find sentences with more than 10 words
    long_sentences = re.findall(pattern, formatted_text)
    pattern = r'\n+'
    # Use re.sub() to replace repeated sequences of newline characters with a single newline
    text_without_repeated_newlines = re.sub(pattern, '\n', long_sentences[0])
    with open(output_path, 'w') as file:
        file.write(self.text)
    return "written txt file"

my_pdf_reader = pdf_reader(input_path="../../Downloads/TheftAct1968(3).pdf",
                           output_name="treason-act-unprocessed")
print(my_pdf_reader.write_pdf())