import os
import openai

from dotenv import load_dotenv, find_dotenv
_ = load_dotenv(find_dotenv()) # read local .env file
openai.api_key = os.environ['OPENAI_API_KEY']


# from transformers import AutoTokenizer, pipeline
# import torch

from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain, RouterChain, SequentialChain
from langchain.llms import HuggingFacePipeline
from langchain.chat_models import ChatOpenAI


from langchain_core.runnables import ConfigurableField

# LCEL-specific
from langchain_core.output_parsers import StrOutputParser
from langchain_community.vectorstores import DocArrayInMemorySearch
from langchain_core.runnables import RunnableParallel, RunnablePassthrough
from langchain_community.embeddings import HuggingFaceEmbeddings

##### LOAD LLM

# account for deprecation of LLM model
import datetime
# Get the current date
current_date = datetime.datetime.now().date()

# Define the date after which the model should be set to "gpt-3.5-turbo"
target_date = datetime.date(2024, 6, 12)

# Set the model variable based on the current date
if current_date > target_date:
    llm_model = "gpt-3.5-turbo"
else:
    llm_model = "gpt-3.5-turbo-0301"




##### TEST

from langchain.chat_models import ChatOpenAI

# To control the randomness and creativity of the generated
# text by an LLM, use temperature = 0.0
llm = ChatOpenAI(temperature=0.0, model=llm_model)


##### LOAD DOCUMENT EMBEDDINGS

from langchain.embeddings import OpenAIEmbeddings
embeddings = OpenAIEmbeddings()


##### DO TEXT SPLITTING

# splitting text file

with open("uploads/fraud.txt") as f:
    example_document_raw = f.read()

from langchain_text_splitters import CharacterTextSplitter

text_splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=1000, # quite small as this is a short text for eg purposes
    chunk_overlap=100,
    length_function=len,
    is_separator_regex=False,
)

example_document = text_splitter.create_documents([example_document_raw])

# vectorise and store the documents in a vector db
vectorstore = DocArrayInMemorySearch.from_documents(
    example_document,
    embedding=embeddings,
)


# retriever is the obj that does cosine similarity on the db to see which docs match your question
retriever = vectorstore.as_retriever()



##### SET UP PROMPT AND MAIN CHAIN #####


# this is the main prompt, will be filled in by the other parts of the chain
template = """Answer the question based only on the following context:
{context}

Question: {question}
"""

prompt = ChatPromptTemplate.from_template(template)

# allows the output to be displayed nicely in this notebook
output_parser = StrOutputParser()


setup_and_retrieval = RunnableParallel(
    {"context": retriever, "question": RunnablePassthrough()}
)
chain = (
    setup_and_retrieval 
    | prompt 
    | llm 
    | output_parser
)

####### RUN THE CHAIN


# run the chain
q1 = "what is this legislation about?"
q2 = "how many types of fraud are there"
q3 = "what is the maximum penalty for fraud"
q4 = "when did this legislation take effect?"
q5 = "where does this legislation apply?"

# run 1 by 1 like this
# a1 = chain.invoke(q1)

# batch them like this 
result = chain.batch([q1, q2, q3, q4, q5])


print(*result)
