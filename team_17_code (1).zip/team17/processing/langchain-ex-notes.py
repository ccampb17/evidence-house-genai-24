import os
import openai
import langchain
import re

from dotenv import load_dotenv, find_dotenv
_ = load_dotenv(find_dotenv()) # read local .env file
openai.api_key = os.environ['OPENAI_API_KEY']

# account for deprecation of LLM model
import datetime
# Get the current date
current_date = datetime.datetime.now().date()

# Define the date after which the model should be set to "gpt-3.5-turbo"
target_date = datetime.date(2024, 6, 12)

# Set the model variable based on the current date
if current_date > target_date:
    llm_model = "gpt-3.5-turbo"
else:
    llm_model = "gpt-3.5-turbo-0301"

from langchain.chat_models import ChatOpenAI
# To control the randomness and creativity of the generated
# text by an LLM, use temperature = 0.0
chat = ChatOpenAI(temperature=0.0, model=llm_model)

def get_completion(prompt, model=llm_model):
    messages = [{"role": "user", "content": prompt}]
    response = openai.ChatCompletion.create(
        model=model,
        messages=messages,
        temperature=0, 
    )
    return response.choices[0].message["content"]

# read in file and split into sections
def read_file_as_list(file_path):
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
            #lines = [line.strip() for line in lines]
            return lines
    except FileNotFoundError:
        print(f"File '{file_path}' not found.")
        return []


input_file = read_file_as_list('outputs/fraud-output.txt')

input_text = '\n'.join(input_file)

print('splitting...')

section_delimiter = r'Document Generated: 2023-04-24'
input_text = input_text.split(section_delimiter)



input_text_sections = [re.sub(pattern=section_delimiter, repl='', string=x) for x in input_text]


template_string = """Translate the text \
that is delimited by triple backticks \
into the following {style}. \
text: ```{text}```
"""

template_string = """You will be given the following piece of text which is a(n) ‘{text_type}’.
Piece of text:
{input_text}
Your task is to produce explanatory notes for the piece of text. \
    Explanatory notes are designed to assist readers who do not have legal training and are unfamiliar with the subject matter of the bill.\
     You must include page numbers and references to where the information is from in the act itself. \
    Only provide the explanatory notes. Do not provide an introduction. Begin your answer with 'Explanatory notes:'\
It must include the following sections:\n \
    Introduction: Explanation of the purpose of the notes, stating that they are meant to assist in understanding the Act \
        but do not form part of the Act itself;\n \
    Background and Policy Objectives: A detailed background section that explains the circumstances and issues that led to\
         the development of the Act. Clear articulation of the policy objectives intended by the Act​​​​; \n\
     Commentary on Sections: A section-by-section commentary that explains the intent and implications of specific sections of the Act.\
         Include a section subtitle for each section, for example: Section 5: “Gain” and “loss”;\n \
    Territorial Application: if applicable what region the legislation applies to; Hansard Reports: \
        Information on the passage of the Act through the legislative process, including references to \
            debates and discussions as recorded in Hansard, providing dates and details of each stage of the process​​;\n \
    Commencement: Details on how and when the Act comes into force, often specifying that commencement will be enacted by order​​;\n \
        and Miscellaneous: Additional sections as needed, such as implications for existing laws, transitional provisions,\
             and any specific exclusions or exceptional circumstances highlighted by the Act​​."""

prompt_string = """
You will be given the following piece of text which is a(n) ‘{text_type}’.\
Piece of text:\
{input_text}\
Your task is to produce explanatory notes for the piece of text. Explanatory notes are \ 
designed to assist readers who do not have legal training and are unfamiliar with the subject \ 
matter of the bill. You must include page numbers and references to where the information \
is from in the act itself.  \n
It must include an overarching summary called ‘Overarching summary’ at the top. \n\
It must include the following information: \n Factual background: An explanation of how the \
provision interacts with other legislation (whether other provisions of the bill or of existing \
legislation); \n Definitions of technical terms used in the bill \n  Illustrative examples of how \
    the bill will work in practice (these might perhaps be worked examples of a calculation or \
examples of how a new offence might be committed) \n An explanation of how the \
department plans to use the provision.  \n It must include the following sections under a \
main title called ‘Typical style’ \n Introduction: Explanation of the purpose of this not, stating \
that they are meant to assist in understanding the Act but do not form part of the Act itself. \n \
    Background and Policy Objectives: A detailed background section that explains the\
circumstances and issues that led to the development of the Act. Clear articulation of the\
 policy objectives intended by the Act​​​​ \n Commentary on Sections: A section-by-section \
commentary that explains the intent and implications of specific sections of the Act. Include a\
 section subtitle for each section, for example: Section 5: “Gain” and “loss”.  \n Territorial \
Application: if applicable what region the legislation applies to. \n \
    Hansard Reports: Information on the passage of the Act through the legislative process, including references to\
 debates and discussions as recorded in Hansard, providing dates and details of each stage \
of the process​​.\n 
Commencement: Details on how and when the Act comes into force, often\
 specifying that commencement will be enacted by order​​.\n Miscellaneous: Additional \
sections as needed, such as implications for existing laws, transitional provisions, and any \
specific exclusions or exceptional circumstances highlighted by the Act​​. \

"""

prompt_string = """You will be given the following piece of text which is a(n) '{text_type}'.\
Piece of text:\
{input_text}\
Your task is to produce explanatory notes for the piece of text. Explanatory notes are \
designed to assist readers who do not have legal training and are unfamiliar with the subject \
matter of the bill. You must include page numbers and references to where the information \
is from in the act itself.  \n
It must be written for a reading age of 9-years-old, used this guidance: \n\
Never assume your reader knows the subject or can read as well as you can \n\
Write in small chunks - include just one idea per sentence \n\
Keep sentences to less than 20 words – split longer sentences into two or more shorter ones.\n\
Split large blocks of text into smaller paragraphs – it makes it easier to read \n\
Keep paragraphs to no more than 3 or 4 sentences \n\
Avoid jargon \n\
Use simple words rather than complicated ones \n\
Follow plain English guidance \n\
Read through your text and get someone else to read it. \n\
It must include an overarching summary called 'Overarching summary' at the top. \n\
It must include the following information: \n Factual background: An explanation of how the \
provision interacts with other legislation (whether other provisions of the bill or of existing \
legislation); \n Definitions of technical terms used in the bill \n  Illustrative examples of how \
    the bill will work in practice (these might perhaps be worked examples of a calculation or \
examples of how a new offence might be committed) \n An explanation of how the \
department plans to use the provision.  \n It must include the following sections under a \
main title called 'Typical style' \n Introduction: Explanation of the purpose of this not, stating \
that they are meant to assist in understanding the Act but do not form part of the Act itself. \n \
    Background and Policy Objectives: A detailed background section that explains the\
circumstances and issues that led to the development of the Act. Clear articulation of the\
 policy objectives intended by the Act​​​​ \n Commentary on Sections: A section-by-section \
commentary that explains the intent and implications of specific sections of the Act. Include a\
 section subtitle for each section, for example: Section 5: "Gain" and "loss".  \n Territorial \
Application: if applicable what region the legislation applies to. \n \
    Hansard Reports: Information on the passage of the Act through the legislative process, including references to\
 debates and discussions as recorded in Hansard, providing dates and details of each stage \
of the process​​.\n
Commencement: Details on how and when the Act comes into force, often\
 specifying that commencement will be enacted by order​​.\n Miscellaneous: Additional \
sections as needed, such as implications for existing laws, transitional provisions, and any \
specific exclusions or exceptional circumstances highlighted by the Act​​. """

from langchain.prompts import ChatPromptTemplate

results_list = []
results_dict = dict()

# for i in range(1,len(input_text_sections)):
for i in range(1,6):
    print(f'STARTING SECTION {i}')
    this_text = input_text_sections[i]
    print(len(this_text))

    print(len(this_text)+len(prompt_string))

    prompt_template = ChatPromptTemplate.from_template(prompt_string)

    text_type = 'act'


    test_response = prompt_template.format_messages(
                        text_type=text_type,
                        input_text=this_text)
    # print(test_response)
    # print(len(test_response))

    # Call the LLM to translate to the style of the customer message
    explanatory_notes = chat(test_response)

    results_list.append(explanatory_notes.content)
    results_dict[this_text] = explanatory_notes.content

    # print(explanatory_notes.content)


import json

with open("llm_output/ex-notes-output.txt", "w") as f:
    json.dump(results_list, f)  # Save list as JSON




